use projects_sql;
SELECT 
    DATE(FROM_UNIXTIME(created_at)) AS created_date,
    DATE(FROM_UNIXTIME(deadline)) AS deadline_date,
    DATE(FROM_UNIXTIME(updated_at)) AS updated_date,
    DATE(FROM_UNIXTIME(state_changed_at)) AS statechanged_date,
    DATE(FROM_UNIXTIME(launched_at)) AS launched_date
FROM projects;

ALTER TABLE projects 
ADD COLUMN created_date DATE,
ADD COLUMN deadline_date DATE,
ADD COLUMN updated_date DATE,
ADD COLUMN statechanged_date DATE,
ADD COLUMN launched_date DATE;

select*from projects;

UPDATE projects
SET created_date = DATE(FROM_UNIXTIME(created_at)),
deadline_date = DATE(FROM_UNIXTIME(deadline)),
updated_date = DATE(FROM_UNIXTIME(updated_at)),
statechanged_date = DATE(FROM_UNIXTIME(state_changed_at)),
launched_date = DATE(FROM_UNIXTIME(launched_at));

select*from projects;