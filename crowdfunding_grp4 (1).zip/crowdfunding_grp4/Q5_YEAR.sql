use projects_sql;
SELECT YEAR(created_date) AS Year,
QUARTER(created_date) AS Quarter,
MONTH(created_date) AS Month,
COUNT(*) AS TotalProjects
FROM Projects
GROUP BY Year, Quarter, Month;
