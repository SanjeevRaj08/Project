use projects_sql;
select*from projects;
SELECT (COUNT(CASE WHEN state = 'successful' THEN 1 END) * 100.0 / COUNT(*)) AS Successful_Percentage
FROM projects;
select*from crowdfunding_category;

SELECT cc.name,  
(COUNT(CASE WHEN p.state = 'successful' THEN 1 END) * 100.0 / COUNT(*)) AS Successful_Percentage
FROM projects p
JOIN crowdfunding_category cc ON p.category_id = cc.id 
GROUP BY cc.name;

select*from calendar;

SELECT YEAR(created_date) AS Year,MONTH(created_date) AS Month,
CONCAT(ROUND((COUNT(CASE WHEN state = 'Successful' THEN 1 END) * 100.0 / COUNT(*)),1),"%") AS Successful_Percentage 
FROM Projects
GROUP BY Year,MONTH
order by YEAR;



SELECT 
    CASE 
        WHEN goal BETWEEN 0 AND 10000 THEN 'Less than 10k'
        WHEN goal BETWEEN 10001 AND 50000 THEN '10k to 50k'
        WHEN goal BETWEEN 50001 AND 100000 THEN '50k to 100k'
        ELSE 'Above 100k'
    END AS goal_usd,
    CONCAT(ROUND((COUNT(CASE WHEN LOWER(state) = 'successful' THEN 1 END) * 100.0 / COUNT(*)), 1), "%") AS Successful_Percentage
FROM Projects
GROUP BY 
    CASE 
        WHEN goal BETWEEN 0 AND 10000 THEN 'Less than 10k'
        WHEN goal BETWEEN 10001 AND 50000 THEN '10k to 50k'
        WHEN goal BETWEEN 50001 AND 100000 THEN '50k to 100k'
        ELSE 'Above 100k'
    END;











