use projects_sql;
SELECT name,backers_count
FROM Projects
WHERE state = 'Successful'
ORDER BY backers_count DESC
LIMIT 5;  

SELECT name,usd_pledged 
FROM Projects
WHERE state = 'Successful'
ORDER BY usd_pledged DESC
LIMIT 5;  
