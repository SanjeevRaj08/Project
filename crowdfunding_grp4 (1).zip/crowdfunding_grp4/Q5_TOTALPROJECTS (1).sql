use projects_sql;
select state,
count(*) AS total_projects
from projects
group by state;
select*from crowdfunding_location;
select*from projects;

SELECT cl.displayable_name,
COUNT(p.location_id) AS total_projects
FROM projects p
JOIN crowdfunding_location cl ON p.location_id = cl.id
GROUP BY cl.displayable_name
ORDER BY total_projects DESC
LIMIT 10;


select*from crowdfunding_category;
SELECT cc.name,
COUNT(p.category_id) AS total_projects
FROM projects p
JOIN crowdfunding_category cc ON p.category_id = cc.id
GROUP BY cc.name
ORDER BY total_projects DESC
LIMIT 10;

















