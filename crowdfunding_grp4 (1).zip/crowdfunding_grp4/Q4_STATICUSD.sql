use projects_sql;
ALTER TABLE projects
ADD COLUMN goal_usd DECIMAL(20, 2);
select*from projects;

UPDATE projects
SET goal_usd = CASE
WHEN static_usd_rate = 0 THEN goal 
ELSE goal * static_usd_rate         
END;

select goal,static_usd_rate,goal_usd
from projects
ORDER BY rand()
LIMIT 100;



