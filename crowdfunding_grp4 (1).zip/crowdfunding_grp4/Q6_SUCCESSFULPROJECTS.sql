use projects_sql;
SELECT COUNT(*) AS Successful_Projects FROM Projects
WHERE state = 'successful';

SELECT SUM(usd_pledged) AS TotalAmountRaised FROM Projects
WHERE state = 'successful';

SELECT SUM(backers_count) AS TotalBackers FROM Projects
WHERE state = 'successful';

SELECT concat(round( AVG(DATEDIFF(FROM_UNIXTIME(state_changed_at), FROM_UNIXTIME(created_at))),0),"days") AS AverageDays FROM Projects
WHERE state = 'Successful';



